# glyphsaver

Fullscreen ASCII screensaver for **Arch Linux + Hyprland**. Your text or logo
animates through 37 terminal text effects — one fullscreen terminal per
monitor, any key exits. Inspired by
[Omarchy's screensaver](https://github.com/basecamp/omarchy); no Omarchy
distro required.

Effects by [TerminalTextEffects](https://github.com/ChrisBuilds/terminaltexteffects)
via the Rust port [`omacom-io/ttfx`](https://github.com/omacom-io/ttfx).

## Features

- **Random or single effect** — all 37 TTE effects (`matrix`, `rain`, `decrypt`,
  `beams`, `burn`, `wipe`, …), random cycling (default) or one fixed effect
- **Two engines, auto-picked** — `ttfx` (fast Rust) preferred, `tte` (original
  Python) as fallback; override per-run or in config
- **Auto-fit text art** — Omarchy wordmark style first (true wordmark font,
  pixel-extracted from the Omarchy logo), then game/display faces (doom, cybermedium,
  chunky, epic, bloody, ghost, graffiti, modular), then classic FIGlet faces,
  then plain; the chosen style is saved as default and reused for later texts
- **19 text styles** — `gly styles` lists them (`omarchy` default); `gly style NAME` switches
- **Preset art gallery** — `gly arts` lists bundled art: heroes (`batman`,
  `superman`, `spider`), `car`, funny (`lenny`, `tableflip`, `shrug`),
  Japanese AA (`torii`, `fuji`, `wave`, `neko`); `gly art batman` sets one
- **Paste your own** — `gly paste` (or `wl-paste | gly paste`) saves piped or
  typed ASCII art, also offered during setup
- **`glyphsaver ascii`** — render words to stdout in the wordmark style
- **Image → ASCII** — PNG/SVG converted via `chafa`; custom `.txt` art supported
- **Per-monitor fullscreen** — one terminal per Hyprland monitor, race-free
  spawn (event-socket sync)
- **Idle integration** — swayidle systemd service: screensaver, warn, lock, screen-off
- **Dotfile-aware setup** — adapts to KoolDots Lua, plain Lua, or classic
  `hyprland.conf` (new/legacy syntax auto-picked); backs up everything, idempotent
- **Toggle + status** — disable idle starts without uninstalling
- **Clean uninstall** — `glyphsaver-uninstall` removes launchers, dotfile hooks,
  and (optionally) settings

## Requirements

| Package | Version tested | Install | Needed for |
|---|---|---|---|
| `ttfx` **or** `python-terminaltexteffects` | ttfx 0.3.2 / tte 0.15.0 | `cargo install --git https://github.com/omacom-io/ttfx` or `yay -S python-terminaltexteffects` | effects engine (at least one) |
| `bash` | 5.3 | `sudo pacman -S bash` | scripts |
| `hyprland` | 0.56.2 | `sudo pacman -S hyprland` | multi-monitor fullscreen (else inline mode) |
| `swayidle` | any | `sudo pacman -S swayidle` | idle handling (service runs it) |
| `jq` | 1.8.2 | `sudo pacman -S jq` | monitor detection, focus checks |
| `socat` | 1.8.1 | `sudo pacman -S socat` | Hyprland event socket |
| `chafa` | 1.18.2 | `sudo pacman -S chafa` | image → ASCII (`set-image`) |
| `alacritty` / `foot` / `ghostty` / `kitty` | any | `sudo pacman -S alacritty foot kitty` | fullscreen host (others work via generic `-e`, may be windowed) |

> `glyphsaver-setup` checks all of these and offers to install the missing ones
> (needs sudo). The AUR package declares them as `depends`/`optdepends`.

## Installation

### Option A — interactive setup (recommended)

```bash
git clone git@github.com:Rajesh2431/glyphsaver.git && cd glyphsaver
./install.sh
```

You are guided through 5 steps:

1. **Dependencies** — offers to install missing ones.
2. **Engine** — `1` auto (recommended), `2` ttfx, `3` tte.
3. **Idle time** — `1` 60s quick · `2` 150s (recommended) · `3` 300s ·
   `4` 480s (before the 10-min lock) · `5` custom · `6` skip.
   Writes `~/.config/glyphsaver/idle.conf` and enables the
   `glyphsaver-idle.service` systemd user unit (swayidle underneath:
   saver → warn 540s → lock 600s → screen-off 720s).
4. **Text/art** — type text (default: your username), then pick a style
   from the numbered menu (`omarchy` wordmark style is default); it renders,
   shows the result, offers a live effect preview, then asks to keep it
   (style saved as default).
5. **Hyprland rules** — see compatibility table below.

Non-interactive equivalent:

```bash
./setup --yes --idle 150 --text "Hello" --engine auto
```

Then preview (no daemon restart needed — systemd owns idle now):

```bash
glyphsaver preview matrix
glyphsaver force   # full run, any key exits
```

### Option B — AUR-style package

```bash
makepkg -si
glyphsaver-setup        # same interactive setup as ./install.sh
```

Installs `glyphsaver` (+ short alias `gly`), `glyphsaver-loop`, `glyphsaver-setup`,
`glyphsaver-uninstall` to `/usr/bin`, assets to `/usr/share/glyphsaver/`.
Package name `glyphsaver` is free on the AUR; see `PKGBUILD` header for
publishing steps.

### Compatibility (any Arch + Hyprland dotfiles)

| Your setup | What `setup` does |
|---|---|
| KoolDots Lua (`user_window_rules.lua` + helper) | appends managed rule block |
| Other Lua `hyprland.lua` | installs `glyphsaver.lua` + one `dofile` line (pcall-guarded) |
| Plain `hyprland.conf` | appends `source` line; new (≥ 0.53) or legacy syntax auto-picked |
| No Hyprland | launcher runs inline in the current terminal |
| `swayidle` also running standalone | stop it to avoid double-firing (`pkill swayidle`) |

## Manual

### Control — `glyphsaver` (short alias: `gly`, e.g. `gly time 150`)

| Command | Effect |
|---|---|
| `glyphsaver` | idle entry point (called by the idle service; no-op if toggled off/running) |
| `glyphsaver force [--effect X] [--fps N] …` | start now, bypassing the toggle |
| `glyphsaver stop` | kill a running screensaver, restore cursor |
| `glyphsaver toggle [on\|off\|status]` | enable/disable idle starts (no arg flips) |
| `glyphsaver status` | running state, toggle state, engines, art, style, idle service |
| `glyphsaver show` | all saved settings (art, style, engine, mode, filters, fps, idle) |
| `glyphsaver preview [EFFECT]` | one effect cycle inline in the current terminal |
| `glyphsaver preview-text "Hi 123"` | render text and preview once without saving |
| `glyphsaver ascii "Hi 123"` | print wordmark-style art to stdout (no save) |
| `glyphsaver list-effects` | the 37 effects |
| `glyphsaver time 150` | set idle timeout (restarts the idle service) |
| `glyphsaver time` | show current idle timeout |
| `glyphsaver text "Hi"` | change the displayed text; **style stays default** |
| `glyphsaver effect matrix` / `random` | fixed effect, or back to random cycling |
| `glyphsaver include "matrix rain"` / `clear` | random allow-list (clears exclude) |
| `glyphsaver exclude "burn"` / `clear` | random block-list (clears include) |
| `glyphsaver fps 120` | frame rate 1–1000 |
| `glyphsaver engine auto\|ttfx\|tte` | effects engine |
| `glyphsaver style mini` / `auto` | default text style (see: `gly styles`) |
| `glyphsaver size` | show scaling (auto-fill, 1 = original, N = fixed) |
| `glyphsaver size 2` | force scale x2 (auto = fill screen from text length) |
| `glyphsaver set-image logo.png` | PNG/SVG → ASCII art (needs `chafa`) |
| `glyphsaver set-art file.txt` | use an existing text-art file |
| `glyphsaver arts` | list bundled presets (heroes, car, funny, Japanese) |
| `glyphsaver art batman` | use a bundled preset instantly |
| `glyphsaver paste` | paste your own ASCII art (`wl-paste \| gly paste`, end typing with Ctrl-D) |
| `glyphsaver edit-art` | open current art in `$EDITOR` |
| `glyphsaver reset-art` | restore the bundled logo |
| `glyphsaver help` | full command help in the terminal |

### Effect loop — `glyphsaver-loop`

```bash
glyphsaver-loop --random                    # default: new random effect each cycle
glyphsaver-loop --effect matrix             # one effect, repeated
glyphsaver-loop --include "matrix rain decrypt"
glyphsaver-loop --exclude "matrix bouncyballs"
glyphsaver-loop --fps 60 --engine tte --art ./logo.txt
glyphsaver-loop --once --effect wipe        # single cycle, then exit (preview)
glyphsaver-loop --list-effects
```

### Style persistence

`SCREENSAVER_FONT` in `~/.config/glyphsaver/config` (`omarchy` default, see
`gly styles`; empty = auto-pick). Saved automatically by setup/`text`.
Changing text later reuses it; overlong text cascades smaller for that
render only, without changing the default.

### Auto sizing

Art is scaled to fill the screen with a ~1-letter margin each side —
short text renders huge, long text stays readable. `SCREENSAVER_SCALE`
controls it: blank (auto, default), `1`/`off` (original size), `2`–`8`
fixed. `gly size [auto|1-8]` views/changes it (re-render text or re-set
art afterwards to apply).

### Config file reference (`~/.config/glyphsaver/config`)

```bash
SCREENSAVER_ENGINE="auto"    # auto | ttfx | tte
SCREENSAVER_FPS="120"        # frame rate
SCREENSAVER_MODE="random"    # random | single
SCREENSAVER_EFFECT="matrix"  # used when MODE=single
SCREENSAVER_INCLUDE=""       # random pool allow-list, e.g. "matrix rain"
SCREENSAVER_EXCLUDE=""       # random pool block-list
SCREENSAVER_ART=""           # art file (empty = Omarchy branding path, then bundled logo)
SCREENSAVER_FONT="omarchy"  # default text style: omarchy|big|block|standard|slant|shadow|digital|bubble|script|small|mini|plain (see: gly styles)
SCREENSAVER_SCALE=""        # auto-fill screen (blank), 1/off = original, 2-8 = fixed
```

CLI flags override the file. Full defaults in `config.example`.

## Uninstallation

```bash
./uninstall.sh              # prompts; keeps settings/art
./uninstall.sh --yes --all  # non-interactive, removes settings/art/state too
```

Removes: running saver, `~/.local/bin` launchers, the AUR package on request
(`sudo pacman -R`), all managed dotfile blocks, the Lua module — never your
own config sections. `hyprctl reload` to apply window-rule changes.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `neither 'ttfx' nor 'tte' found` | install an engine (see Requirements) |
| Tiny plain text instead of styled art | pick a fitting style: `gly styles`, then `gly style NAME` + `gly text` |
| Saver stays windowed | use Alacritty/Foot/Ghostty/Kitty; `hyprctl reload`; check class `glyphsaver` in `hyprctl clients` |
| Idle never fires | `systemctl --user status glyphsaver-idle`; needs swayidle installed; `toggle status` says ON |
| Lua errors after setup | restore `*.bak`, report Hyprland version (`hyprctl version`) |
| Two savers at once / stuck cursor | `glyphsaver stop` |

## Credits

- Screensaver concept, logo, wordmark art:
  [`basecamp/omarchy`](https://github.com/basecamp/omarchy) — the `omarchy`
  text style (`fonts/omarchy.flf`) is pixel-extracted from their `logo.txt`
  (unicase; remaining A–Z, 0–9 and punctuation hand-drawn here in the same
  10-row block style)
- Game/display FIGlet fonts (doom, cybermedium, chunky, epic, bloody, ghost,
  graffiti, modular): [`xero/figlet-fonts`](https://github.com/xero/figlet-fonts);
  classic faces from stock FIGlet 2.2.5
- Effects engine: [TerminalTextEffects](https://github.com/ChrisBuilds/terminaltexteffects) by ChrisBuilds; Rust port [omacom-io/ttfx](https://github.com/omacom-io/ttfx)
- Standalone Arch port, setup/uninstall/packaging: this repo (MIT, see `LICENSE`)
